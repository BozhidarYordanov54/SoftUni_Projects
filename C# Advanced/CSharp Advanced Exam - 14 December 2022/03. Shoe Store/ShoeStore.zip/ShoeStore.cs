﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShoeStore
{
    public class ShoeStore
    {
        public string Name { get; set; }
        public int StorageCapacity { get; set; }

        public List<Shoe> Shoes = new List<Shoe>();

        public ShoeStore(string name, int capacity)
        {
            Name = name;
            StorageCapacity = capacity;
        }
        public int Count
        {
            get { return Shoes.Count; }
        }

        public string AddShoe(Shoe shoe)
        {
            if (Shoes.Count == StorageCapacity)
            {
                return "No more space in the storage room.";
            }
            Shoes.Add(shoe);
            return $"Successfully added {shoe.Type} {shoe.Material} pair of shoes to the store.";
        }

        public int RemoveShoes(string material)
        {
            int count = Shoes.RemoveAll(shoe => shoe.Material.ToLower() == material.ToLower());
            return count;
        }

        public List<Shoe> GetShoesByType(string type)
        {
            return Shoes.FindAll(shoe => shoe.Type.ToLower() == type.ToLower());
        }

        public Shoe GetShoeBySize(double size)
        {
            return Shoes.Find(shoe => shoe.Size == size);
        }

        public string StockList(double size, string type)
        {
            List<Shoe> matchingShoes = Shoes.FindAll(shoe => shoe.Size == size && shoe.Type.ToLower() == type.ToLower());
            if (matchingShoes.Count == 0)
            {
                return "No matches found!";
            }

            string stockList = $"Stock list for size {size} - {type} shoes:\n";
            foreach (Shoe shoe in matchingShoes)
            {
                stockList += $"{shoe}\n";
            }
            return stockList;
        }
    }
    //public string StockList(double size, string type)
    //{
    //    System.Console.WriteLine($"Stock list for size {size} - {type} shoes");
    //
    //    StringBuilder sb = new StringBuilder();
    //
    //    foreach (Shoe shoe in Shoes)
    //    {
    //        if (shoe.Size == size && shoe.Type == type)
    //        {
    //            sb.AppendLine($"Size {shoe.Size}, {shoe.Material} {shoe.Brand} {shoe.Type} shoe.");
    //        }
    //    }
    //    return sb.ToString();
    //}
    //
    //public string GetShoeBySize(double size)
    //{
    //    StringBuilder sb = new StringBuilder();
    //    for (int i = 0; i < Shoes.Count; i++)
    //    {
    //        if (size == Shoes[i].Size)
    //        {
    //            sb.AppendLine($"Size {Shoes[i].Size}, {Shoes[i].Material} {Shoes[i].Brand} {Shoes[i].Type} shoe.");
    //        }
    //    }
    //    return sb.ToString();
    //}
    //
    //public List<string> GetShoesByType(string type)
    //{
    //    List<string> shoes = new List<string>();
    //
    //    for (int i = 0; i < Shoes.Count; i++)
    //    {
    //        if (Shoes[i].Type.ToLower() == type)
    //        {
    //            shoes.Add($"Size {Shoes[i].Size}, {Shoes[i].Material} {Shoes[i].Brand} {Shoes[i].Type} shoe.");
    //        }
    //    }
    //
    //    return shoes;
    //}
    //public int RemoveShoes(string materialToRemove)
    //{
    //    List<Shoe> shoes = GetShoes();
    //
    //    int count = 0;
    //
    //    foreach (Shoe shoe in Shoes)
    //    {
    //        if (shoe.Material == materialToRemove)
    //        {
    //            count++;
    //        }
    //    }
    //
    //    return count;
    //}
    //public string AddShoe(Shoe shoe)
    //{
    //    if (StorageCapacity <= 0)
    //    {
    //        return "No more space in the storage room.";
    //    }
    //    Shoes.Add(shoe);
    //    StorageCapacity--;
    //
    //    return $"Successfully added {shoe.Type} {shoe.Material} pair of shoes to the store.";
    //}
    //
    //private List<Shoe> GetShoes()
    //{
    //    return new List<Shoe>();
    //}
    //
}
