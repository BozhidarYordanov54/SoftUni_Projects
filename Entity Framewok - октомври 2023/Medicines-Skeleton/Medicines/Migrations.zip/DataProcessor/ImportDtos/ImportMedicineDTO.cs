﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.DataProcessor.ImportDtos
{
    public class ImportMedicineDTO
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Category { get; set; }
        public DateTime ProductionDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Producer { get; set; }
    }
}
