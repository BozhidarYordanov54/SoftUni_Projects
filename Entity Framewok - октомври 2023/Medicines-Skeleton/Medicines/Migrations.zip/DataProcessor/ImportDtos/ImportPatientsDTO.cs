﻿using Medicines.Data.Models;
using Medicines.Data.Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicines.DataProcessor.ImportDtos
{
    public class ImportPatientsDTO
    {
        [JsonProperty("FullName")]
        public string FullName {  get; set; }

        [JsonProperty("AgeGroup")]
        public AgeGroup AgeGroup { get; set; }

        [JsonProperty("Gender")]
        public Gender Gender { get; set; }

        public List<int> PatientMedicines { get; set; }
    }
}
