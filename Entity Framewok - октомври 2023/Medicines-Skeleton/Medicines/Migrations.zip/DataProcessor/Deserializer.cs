﻿namespace Medicines.DataProcessor
{
    using Medicines.Data;
    using Medicines.Data.Models;
    using Medicines.Data.Models.Enums;
    using Medicines.DataProcessor.ImportDtos;
    using Newtonsoft.Json;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Text;
    using System.Xml.Linq;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid Data!";
        private const string SuccessfullyImportedPharmacy = "Successfully imported pharmacy - {0} with {1} medicines.";
        private const string SuccessfullyImportedPatient = "Successfully imported patient - {0} with {1} medicines.";

        public static string ImportPatients(MedicinesContext context, string jsonString)
        {
            StringBuilder output = new StringBuilder();

            List<ImportPatientsDTO> patientsDTO = JsonConvert.DeserializeObject<List<ImportPatientsDTO>>(jsonString);

            List<Patient> patients = new List<Patient>();

            context.Database.EnsureCreated();

            foreach (var dto in patientsDTO)
            {
                var patient = new Patient
                {
                    FullName = dto.FullName,
                    AgeGroup = dto.AgeGroup,
                    Gender = dto.Gender,
                    PatientsMedicines = dto.PatientMedicines.Select(medicineId => new PatientMedicine
                    {
                        MedicineId = medicineId
                    }).ToList()
                };

                patients.Add(patient);

            }

            foreach (var patient in patients)
            {
                if (patient.FullName != null || Enum.IsDefined(typeof(AgeGroup), patient.AgeGroup) || Enum.IsDefined(typeof(Gender), patient.Gender))
                {
                    context.Add(patient);
                    context.SaveChanges();

                    output.AppendLine(string.Format(SuccessfullyImportedPatient, patient.FullName, patient.PatientsMedicines.Count));
                }
                else
                {
                    output.AppendLine(ErrorMessage);
                }
            }

            return output.ToString();
        }

        public static string ImportPharmacies(MedicinesContext context, string xmlString)
        {
            return string.Empty;
        }

        private Pharmacy MapToPharmacyEntity(ImportPharmacyDTO pharmacyDTO)
        {
            // Implement mapping logic from PharmacyDTO to Pharmacy entity
            return new Pharmacy
            {
                Name = pharmacyDTO.Name,
                PhoneNumber = pharmacyDTO.PhoneNumber,
                IsNonStop = pharmacyDTO.IsNonStop,
                Medicines = new List<Medicine>()
            };
        }

        private Medicine MapToMedicineEntity(ImportMedicineDTO medicineDTO, int pharmacyId)
        {
            // Implement mapping logic from MedicineDTO to Medicine entity
            return new Medicine
            {
                Name = medicineDTO.Name,
                Price = medicineDTO.Price,
                Category = (Category)medicineDTO.Category,
                ProductionDate = medicineDTO.ProductionDate,
                ExpiryDate = medicineDTO.ExpiryDate,
                Producer = medicineDTO.Producer,
                PharmacyId = pharmacyId
            };
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}
