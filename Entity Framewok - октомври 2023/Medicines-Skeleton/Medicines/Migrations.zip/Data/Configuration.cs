﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=USERPC\SQLEXPRESS;Database=Medicines;Integrated Security=True";
    }
}
