﻿namespace RobotService.Repositories
{
    public class SpecializedArm : Supplement
    {
        public SpecializedArm() : base(10045, 10_000)
        {

        }
    }
}
