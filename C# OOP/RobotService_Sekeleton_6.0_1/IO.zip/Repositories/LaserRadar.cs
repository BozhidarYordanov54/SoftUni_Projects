﻿namespace RobotService.Repositories
{
    public class LaserRadar : Supplement
    {
        public LaserRadar() : base(20082, 5000)
        {

        }
    }
}
