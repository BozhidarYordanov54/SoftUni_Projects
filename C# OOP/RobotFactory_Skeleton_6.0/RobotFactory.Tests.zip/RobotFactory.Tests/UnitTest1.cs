using NUnit.Framework;

namespace RobotFactory.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void ProduceRobot_WhenCapacityAvailable_ShouldProduceRobot()
        {
            // Arrange
            Factory factory = new Factory("TestFactory", 5);

            // Act
            string result = factory.ProduceRobot("TestModel", 1000, 1);

            // Assert
            Assert.AreEqual("Produced --> Robot model: TestModel IS: 1, Price: 1000.00", result);
            Assert.AreEqual(1, factory.Robots.Count);
        }

        [Test]
        public void ProduceRobot_WhenCapacityFull_ShouldNotProduceRobot()
        {
            // Arrange
            Factory factory = new Factory("TestFactory", 1);
            factory.ProduceRobot("TestModel", 1000, 1);

            // Act
            string result = factory.ProduceRobot("TestModel", 1000, 1);

            // Assert
            Assert.AreEqual("The factory is unable to produce more robots for this production day!", result);
            Assert.AreEqual(1, factory.Robots.Count);
        }

        [Test]
        public void ProduceSupplement_ShouldProduceSupplement()
        {
            // Arrange
            Factory factory = new Factory("TestFactory", 5);

            // Act
            string result = factory.ProduceSupplement("TestSupplement", 1);

            // Assert
            Assert.AreEqual("Supplement: TestSupplement IS: 1", result);
            Assert.AreEqual(1, factory.Supplements.Count);
        }

        [Test]
        public void UpgradeRobot_WhenSupplementCompatible_ShouldUpgradeRobot()
        {
            // Arrange
            Factory factory = new Factory("TestFactory", 5);
            Robot robot = new Robot("TestModel", 1000, 1);
            factory.Robots.Add(robot);
            Supplement supplement = new Supplement("TestSupplement", 1);
            factory.Supplements.Add(supplement);

            // Act
            bool result = factory.UpgradeRobot(robot, supplement);

            // Assert
            Assert.IsTrue(result);
            Assert.AreEqual(1, robot.Supplements.Count);
            Assert.AreEqual(supplement, robot.Supplements[0]);
        }

        [Test]
        public void UpgradeRobot_WhenSupplementIncompatible_ShouldNotUpgradeRobot()
        {
            // Arrange
            Factory factory = new Factory("TestFactory", 5);
            Robot robot = new Robot("TestModel", 1000, 1);
            factory.Robots.Add(robot);
            Supplement supplement = new Supplement("TestSupplement", 2);
            factory.Supplements.Add(supplement);

            // Act
            bool result = factory.UpgradeRobot(robot, supplement);

            // Assert
            Assert.IsFalse(result);
            Assert.AreEqual(0, robot.Supplements.Count);
        }
    }
}
