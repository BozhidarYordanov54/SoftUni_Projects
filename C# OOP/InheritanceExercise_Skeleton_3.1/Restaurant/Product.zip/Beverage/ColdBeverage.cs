﻿namespace Restaurant
{
    public class ColdBevarage : Beverage
    {
        public ColdBevarage(string name, decimal price, double mililiters) : base(name, price, mililiters)
        {

        }
    }
}
