﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters.Elf
{
    public class Elf : Hero
    {
        public Elf(string name, int level) : base(name, level) 
        {
            Username = name;
            Level = level;
        }
    }
}
