﻿namespace FoodShortage
{
    public interface INameAge
    {
        public string Name { get; }
        public int Age { get; }
    }
}
