﻿namespace BirthdayCelebrations
{
    public interface INameBirthday
    {
        public string Name { get; }
        public string Birthdate { get; }
    }
}