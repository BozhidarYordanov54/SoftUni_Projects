﻿namespace BirthdayCelebrations
{
    public interface IId
    {
        public string Id { get; }
    }
}