﻿namespace Telephony
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] phoneNumbers = Console.ReadLine().Split(" ");
            string[] urls = Console.ReadLine().Split(" ");

            ISmartPhone smartPhone = new SmartPhone();
            IPhone phone = new StationaryPhone();


            foreach (string phoneNumber in phoneNumbers) 
            {
                if (phoneNumber.Length == 10)
                {
                    smartPhone.Call(phoneNumber);
                }
                else if (phoneNumber.Length == 7) 
                { 
                    phone.Call(phoneNumber);
                }
            }

            foreach (string url in urls) 
            {
                smartPhone.Browse(url);
            }
        }
    }
}