﻿namespace Telephony
{
    public interface ISmartPhone : IPhone
    {
        void Browse(string url);
    }

}